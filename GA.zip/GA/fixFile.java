//Accepts as input a file, copies the file as [filename]_orignal,
//and rewrites the file to excise '^M's associated with transferring
//a text file from Windows to Unix.
//BTW under unix dos2unix does the same thing
//Usage: java fixFile [filename]

import java.io.*;
import java.lang.Object.*;
import java.nio.file.*;

public class fixFile 
{
 public static void main(String[] args) throws IOException 
    {
//Copies file as "[file] original"
        String current = System.getProperty("user.dir");
        Path dir = Paths.get(current);
        Path source = dir.resolve(args[0]);
        Path dest = dir.resolve(args[0] + "_original");
        try {
            Files.copy(source, dest);
            }
        catch (IOException ioException)
            {
            System.out.println("Whoops...IOException!");
            System.exit(1);
            }

//Rewrites original file to excise ^M

        BufferedReader inputStream  = null;
        PrintWriter outputStream    = null;

        try {
            inputStream = new BufferedReader(new FileReader(args[0] + "_original"));
            outputStream = new PrintWriter(new FileWriter(args[0]));

            String l;
            while ((l = inputStream.readLine()) != null) {
                outputStream.println(l.replace("^M", ""));
                }
            }
        finally
            {
                if (inputStream != null)
                {
                    inputStream.close();
                }
                if (outputStream != null)
                {
                    outputStream.close();
                }
            }
    }
}
